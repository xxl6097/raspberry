package com.het.protocol.coder.encode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.exception.DecodeException;
import com.het.protocol.coder.exception.EncodeException;
import com.het.protocol.util.PacketConst;
import com.het.protocol.util.ProtoUtils;

import java.nio.ByteBuffer;
/**
 * v42版本协议格式
 * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * | 0xF2 | Protocol Version | Protocol Type | Command Type | Mac Addr | Device Type | Frame Control & WIFI status | Frame SN | Reserved | Length | Frame Body | Frame Body FCS | FCS  |
 * |-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
 * | 1byte|       1byte      |     1byte     |      2byte   |   6byte  |     8byte   |               2byte         |   4byte  |   8byte  |  2byte |   Nbyte    |       2byte    | 2byte|
 * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * */
public class ProtocolF242Encoder extends AbstractEncoder {

    @Override
    void encode(ProtocolBean bean, ByteBuffer buffer) throws DecodeException {
        buffer.put(bean.getHead());
        buffer.put(bean.getProtoVersion());
        buffer.put(bean.getProtoType());
        buffer.putShort(bean.getCommand());
        buffer.put(encodeMacAddress(bean.getDevMacAddr()));
        buffer.put(encodeDevice(bean));
        buffer.put((byte) bean.getDataState());
        buffer.put((byte) bean.getWifiState());
        buffer.putInt((int) bean.getFrameSN());
        byte[] reserved = bean.getReserved();
        if (reserved == null || reserved.length != 8) {
            reserved = new byte[8];
        }
        buffer.put(reserved);

        byte[] body = bean.getBody();
        short bodylen = (short) (body == null ? 0 : body.length);
        buffer.putShort(bodylen);


        if (body != null && bodylen > 0) {
            buffer.put(body);
            byte[] frameBodyCrc = ProtoUtils.CRC16Calc(body, body.length);
            buffer.put(frameBodyCrc);
        }

        buffer.put(encodeCRC(buffer.array(), getDataLen(bean) - 3));
    }

    @Override
    short getDataLen(ProtocolBean bean) throws DecodeException {
        byte[] body = bean.getBody();
        int dataLen = PacketConst.PACKET_F242_LEN + (body == null ? 0 : body.length);
        return (short) dataLen;
    }

    @Override
    byte[] encodeDevice(ProtocolBean bean) throws DecodeException {
        ByteBuffer b = ByteBuffer.allocate(8);
        b.putInt(bean.getCustomerId());
        b.put((byte) bean.getDevType());
        b.put((byte) bean.getDevSubType());
        b.putShort((short) bean.getDataVersion());
        b.flip();
        return b.array();
    }
}
