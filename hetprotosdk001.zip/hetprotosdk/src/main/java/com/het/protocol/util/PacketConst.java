package com.het.protocol.util;

public class PacketConst {
    public final static int PACKET_F241_LEN = 18;
    public final static int PACKET_F242_LEN = 39;
    public final static int PACKET_5A_LEN = 35;
}
