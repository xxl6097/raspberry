package com.java.pi.httpserver.core.impl;

import com.java.pi.api.RaspBerryApi;
import com.java.pi.httpserver.core.AbstractGetHttpFactory;
import com.java.pi.httpserver.util.Util;
import com.java.pi.util.Logc;

import java.util.Map;

public class PiImpl extends AbstractGetHttpFactory {
    final String PATH_MI_SOCKET_PLUS = "/v1/pi/switch";

    @Override
    protected String onMessageReceive(String path, Map<String, String> param) {
        Logc.d("=========================EMQTTImpl :" + path + " " + (param == null ? "param is null" : param.toString()));
        String result = null;
        if (Util.isEmpty(path))
            return result;
        if (param == null)
            return result;
        if (path.startsWith(PATH_MI_SOCKET_PLUS)) {
            result = miSwitch(param);
        }
        return result;
    }

    private String miSwitch(Map<String, String> param) {
        String result = "no";
        String entityid = param.get("entityid");
        String callback = param.get("callback");
        if (Util.isEmpty(callback)) {
            callback = "callback";
        }
        if (Util.isEmpty(entityid)) {
            result = "entityid is null";
            String data = ";" + callback + "(" + result + ");";
            return data;
        }
        String state = param.get("state");
        if (Util.isEmpty(state)) {
            result = "state is null";
            String data = ";" + callback + "(" + result + ");";
            return data;
        }
        if (entityid.equals("misocketplush")){
            if (state.equals("on")){
                boolean is = RaspBerryApi.MiSocketTurnOn();
                result = is ? "yes" : "no";
            }else{
                boolean is = RaspBerryApi.MiSocketTurnOff();
                result = is ? "yes" : "no";
            }
        }else if(entityid.equals("misocketplushusb")){
            if (state.equals("on")){
                boolean is = RaspBerryApi.MiSocketUSBTurnOn();
                result = is ? "yes" : "no";
            }else{
                boolean is = RaspBerryApi.MiSocketUSBTurnOff();
                result = is ? "yes" : "no";
            }
        }else if(entityid.equals("mac")){
            boolean is = RaspBerryApi.WakeUpMyMacOs();
            result = is ? "yes" : "no";
        }else if(entityid.equals("homeassistant")){
            if (state.equals("restart")){
                boolean is = RaspBerryApi.HomeAssistantRestart();
                result = is ? "yes" : "no";
            }
        }


        String data = ";" + callback + "(" + result + ");";
        return data;
    }
}
