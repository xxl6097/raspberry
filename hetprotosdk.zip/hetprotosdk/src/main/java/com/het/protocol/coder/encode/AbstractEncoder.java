package com.het.protocol.coder.encode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.encode.inter.Encoder;
import com.het.protocol.coder.exception.DecodeException;
import com.het.protocol.coder.exception.EncodeException;
import com.het.protocol.util.ProtoUtils;

import java.nio.ByteBuffer;

public abstract class AbstractEncoder implements Encoder {
    @Override
    public byte[] encode(Object data) throws EncodeException {
        if (data == null)
            return null;
        if (data instanceof ProtocolBean) {
            ProtocolBean bean = (ProtocolBean) data;
            ByteBuffer buffer = ByteBuffer.allocate(getDataLen(bean));
            encodeDevice(bean);
            encode(bean, buffer);
            return buffer.array();

        }
        return null;
    }

    protected byte[] encodeCRC(byte[] data, int len) throws DecodeException {
        byte[] crc = new byte[len];
        System.arraycopy(data, 1, crc, 0, len);
        byte[] fcs = ProtoUtils.CRC16Calc(crc, crc.length);
        return fcs;
    }

    protected byte[] encodeMacAddress(String mac) {
        if (!ProtoUtils.isNull(mac)) {
            if (ProtoUtils.hexStringToBytes(mac) != null && ProtoUtils.hexStringToBytes(mac).length == 6)
                return ProtoUtils.hexStringToBytes(mac);
        }
        return new byte[6];
    }

    abstract void encode(ProtocolBean bean, ByteBuffer buffer) throws DecodeException;

    abstract short getDataLen(ProtocolBean bean) throws DecodeException;

    abstract byte[] encodeDevice(ProtocolBean bean) throws DecodeException;
}
