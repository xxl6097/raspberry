package com.java.pi.api;

import com.java.pi.httpserver.http.SimpleHttpUtils;
import com.java.pi.util.PIConst;

public class RaspBerryApi {

    private static String MiSocketSwitch(){
        String host = "http://192.168.1.102:8123/api/services/switch/turn_off";
        String body = "{\"entity_id\": \"switch.mi_socket_plus\"}";
        try {
            String result = SimpleHttpUtils.post(host,body.getBytes());
            System.out.println(result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return null;
    }


    public static boolean HomeAssistantRestart(){
        String host = PIConst.Pi.HOST + "/api/services/homeassistant/restart";
        try {
            String result = SimpleHttpUtils.post(host,"".getBytes());
            System.out.println(result);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return false;
    }

    public static boolean WakeUpMyMacOs(){
        return MiSwitch(PIConst.Pi.MAC_WAKE_UP,PIConst.Pi.TURN_ON);
    }


    public static boolean MiSocketUSBTurnOn(){
        return MiSwitch(PIConst.Pi.MI_SOCKET_USB,PIConst.Pi.TURN_ON);
    }

    public static boolean MiSocketUSBTurnOff(){
        return MiSwitch(PIConst.Pi.MI_SOCKET_USB,PIConst.Pi.TURN_OFF);
    }

    public static boolean MiSocketTurnOn(){
        return MiSwitch(PIConst.Pi.MI_SOCKET,PIConst.Pi.TURN_ON);
    }

    public static boolean MiSocketTurnOff(){
        return MiSwitch(PIConst.Pi.MI_SOCKET,PIConst.Pi.TURN_OFF);
    }

    private static boolean MiSwitch(String entityId,String param){
        String host = PIConst.Pi.HOST + "/api/services/switch/"+param;
        String body = "{\"entity_id\": \""+ entityId +"\"}";
        try {
            String result = SimpleHttpUtils.post(host,body.getBytes());
            System.out.println(result);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return false;
    }

    public static void main(String[] args) {
//        MiSocketTurnOn();
//        MiSocketTurnOff();
//        MiSocketSwitch();
//        HomeAssistantRestart();
    }
}
