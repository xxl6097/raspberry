package com.java.pi;

import com.java.pi.httpserver.Server;
import com.java.pi.wifi.LanDiscover;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        try {
            Server.start(8888);
        } catch (IOException e) {
            e.printStackTrace();
        }
//        String html = null;
//        try {
//            Map<String, String> headers = new HashMap<>();
//            headers.put("username","admin");
//            headers.put("password","public");
//            html = SimpleHttpUtils.get("http://uuxia.cn:8080/api/v2/nodes/emq@127.0.0.1/clients",headers);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println(html);





        /*LanDiscover lanDiscover = new LanDiscover();
        final String pcMacAddr = "C8:E7:D8:DE:5C:62";
        final String iosMacAddr = "50:7A:55:E9:9F:CC";
//        final String iosMacAddr = "DC:A9:04:C6:F5:66";
        String locIp = LanDiscover.getLocAddress();
        lanDiscover.discoverLoop(10 * 1000, locIp, new LanDiscover.OnDiscoverDevice() {
            @Override
            public boolean onDeviceState(boolean online, LanDiscover.Device device) {
                if (device != null && device.mac != null) {
                    String curMac = device.mac;
                    curMac = curMac.replaceAll(":","");
                    curMac = curMac.replaceAll("-","");
                    String tarMac = iosMacAddr;
                    tarMac = tarMac.replaceAll(":","");
                    tarMac = tarMac.replaceAll("-","");
                    if (curMac.toUpperCase().equals(tarMac.toUpperCase())) {
                        if (online) {
                            System.out.println("夏小力的Iphone上线啦~~~");
                        }else{
                            System.out.println("夏小力的Iphone离线啦~~~");
                        }
                    }
                }
//                System.out.println(online+"~~~"+device.toString());
                return true;
            }

            @Override
            public void onLogc(String str) {
//                System.err.println(str);
            }
        });*/







        //通过主机名称得到IP地址
//        InetAddress address = null;
//        try {
//            String ip = "192.168.1.106";
//            address = InetAddress.getByName(ip);
//            System.out.println(": "+address.toString()+": "+address.getHostName());
//        } catch (UnknownHostException e) {
//            e.printStackTrace();
//        }


//        try {
//            System.out.println("sssssssss "+InetAddress.getLocalHost().getHostName());
//        } catch (UnknownHostException e) {
//            e.printStackTrace();
//        }


    }


}
