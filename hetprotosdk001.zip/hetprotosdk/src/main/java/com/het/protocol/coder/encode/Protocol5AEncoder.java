package com.het.protocol.coder.encode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.exception.DecodeException;
import com.het.protocol.util.PacketConst;

import java.nio.ByteBuffer;

/**
 * --------------------------------------------------------------------------------------------------------
 * | 0x5A | 数据长度 | 框架版本 | 协议类型 | 设备编码 | Mac地址 | 数据帧序列号 | 保留字 | 数据类型 | 数据内容| 检验码FCS  |
 * |-------------------------------------------------------------------------------------------------------
 * | 1byte|  2byte |  1byte |   1byte |  8byte |  6byte  |   4byte   | 8byte |   2byte | nbyte|2byte
 * ------------------------------------------------------------------------------------------
 */
public class Protocol5AEncoder extends AbstractEncoder {

    @Override
    void encode(ProtocolBean bean, ByteBuffer buffer) throws DecodeException {
        buffer.put(bean.getHead());
        int dataLen = getDataLen(bean);
        buffer.putShort((short) (dataLen - 1));
        buffer.put(bean.getProtoVersion());
        buffer.put(bean.getProtoType());
        buffer.put(encodeDevice(bean));
        buffer.put(encodeMacAddress(bean.getDevMacAddr()));
        buffer.putInt((int) bean.getFrameSN());
        byte[] reserved = bean.getReserved();
        if (reserved == null || reserved.length != 8) {
            reserved = new byte[8];
        }
        buffer.put(reserved);
        buffer.putShort(bean.getCommand());
        if (bean.getBody() != null && bean.getBody().length > 0) {
            buffer.put(bean.getBody());
        }
        buffer.put(encodeCRC(buffer.array(), dataLen - 3));
    }

    @Override
    short getDataLen(ProtocolBean bean) throws DecodeException {
        byte[] body = bean.getBody();
        int dataLen = PacketConst.PACKET_5A_LEN + (body == null ? 0 : body.length);
        return (short) dataLen;
    }

    @Override
    byte[] encodeDevice(ProtocolBean bean) throws DecodeException {
        ByteBuffer b = ByteBuffer.allocate(8);
        b.putInt(bean.getCustomerId());
        b.putShort((short) bean.getDevType());
        b.put((byte) bean.getDevSubType());
        b.put((byte) bean.getDataVersion());
        b.flip();
        return b.array();
    }
}
