package com.het.protocol.coder.decode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.exception.DecodeException;

import java.nio.ByteBuffer;

/**
 * v41版本协议格式
 * -------------------------------------------------------------------------------------------------------------------------
 * | 0xF2 | Protocol Version | Protocol Type | Command Type | Mac Addr | Device Type | Reserved | Length | Frame Body | FCS  |
 * |-------------------------------------------------------------------------------------------------------------------------|
 * | 1byte|       1byte      |     1byte     |      2byte   |   6byte  |     2byte   |   1byte  |  2byte |   Nbyte    | 2byte|
 * -------------------------------------------------------------------------------------------------------------------------
 */
public class ProtocolF241Decoder extends AbstractDecoder {
    final int PACKET_SIZE = 18;
    private ProtocolBean bean;

    @Override
    void validate(byte[] bytes) throws DecodeException {
        if (bytes == null) {
            throw new DecodeException("data is null", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
        int total = bytes.length;
        if (total < PACKET_SIZE) {
            throw new DecodeException("body less total", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
        if (total <= 0) {
            throw new DecodeException("data len is zero", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
    }

    @Override
    byte[] decode(ByteBuffer buffer) throws DecodeException {
        bean = new ProtocolBean();
        bean.setHead(buffer.get());
        bean.setProtoVersion(buffer.get());
        bean.setProtoType(buffer.get());
        bean.setCommand(buffer.getShort());
        byte[] mac = new byte[6];
        buffer.get(mac);
        bean.setDevMacAddr(decodeDevMacAddr(mac));
        byte[] dev = new byte[2];
        buffer.get(dev);
        byte[] reserved = new byte[1];
        buffer.get(reserved);
        bean.setReserved(reserved);

        short readBodyLen = buffer.getShort();
        bean.setLength(readBodyLen);
        int bodyLen = buffer.capacity() - PACKET_SIZE;
        if (bean.getLength() != bodyLen) {
            throw new DecodeException("read size is " + bean.getLength() + " total is " + buffer.capacity() + ", actually body len is " + bodyLen, DecodeException.ERR.DECODE_DATALEN_ERROR);
        }

        byte[] body = new byte[bean.getLength()];
        buffer.get(body);
        bean.setBody(body);
        byte[] crc = new byte[2];
        buffer.get(crc);
        bean.setFcs(crc);
        return dev;
    }

    @Override
    byte[] getCRC() throws DecodeException {
        return bean.getFcs();
    }


    @Override
    int getCrcBodySize() throws DecodeException {
        if (bean == null)
            throw new DecodeException("get crc body error,data is null", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        int len = PACKET_SIZE + bean.getLength() - 3;
        return len;
    }

    @Override
    void decodeDevice(byte[] dev) throws DecodeException {
        if (dev == null)
            throw new DecodeException("data len is zero", DecodeException.ERR.DECODE_DEV_ERROR);
        if (dev.length != 2)
            throw new DecodeException("data len is not 2", DecodeException.ERR.DECODE_DEV_ERROR);
        ByteBuffer b = ByteBuffer.allocate(dev.length);
        b.put(dev);
        b.flip();
        bean.setDevType(b.get());
        bean.setDevSubType(b.get());
    }

    @Override
    ProtocolBean toBean() {
        return bean;
    }
}
