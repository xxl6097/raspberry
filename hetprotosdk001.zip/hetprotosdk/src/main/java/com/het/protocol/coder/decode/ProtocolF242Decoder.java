package com.het.protocol.coder.decode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.exception.DecodeException;
import com.het.protocol.util.PacketConst;

import java.nio.ByteBuffer;
/**
 * v42版本协议格式
 * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * | 0xF2 | Protocol Version | Protocol Type | Command Type | Mac Addr | Device Type | Frame Control & WIFI status | Frame SN | Reserved | Length | Frame Body | Frame Body FCS | FCS  |
 * |-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
 * | 1byte|       1byte      |     1byte     |      2byte   |   6byte  |     8byte   |               2byte         |   4byte  |   8byte  |  2byte |   Nbyte    |       2byte    | 2byte|
 * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * */
public class ProtocolF242Decoder extends AbstractDecoder {
    private ProtocolBean bean;
    @Override
    void validate(byte[] bytes) throws DecodeException {
        if (bytes == null) {
            throw new DecodeException("data is null", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
        int total = bytes.length;
        if (total < PacketConst.PACKET_F242_LEN) {
            throw new DecodeException("body less total", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
        if (total <= 0) {
            throw new DecodeException("data len is zero", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        }
    }

    @Override
    byte[] decode(ByteBuffer buffer) throws DecodeException {
        bean = new ProtocolBean();
        bean.setHead(buffer.get());
        bean.setProtoVersion(buffer.get());
        bean.setProtoType(buffer.get());
        bean.setCommand(buffer.getShort());
        byte[] mac = new byte[6];
        buffer.get(mac);
        bean.setDevMacAddr(decodeDevMacAddr(mac));
        byte[] dev = new byte[8];
        buffer.get(dev);
        bean.setDataState(buffer.get());
        bean.setWifiState(buffer.get());
        bean.setFrameSN(buffer.getInt());
        byte[] reserved = new byte[8];
        buffer.get(reserved);
        bean.setReserved(reserved);
        bean.setLength(buffer.getShort());
        if (bean.getLength() > 0) {
            byte[] body = new byte[bean.getLength()];
            buffer.get(body);
            bean.setBody(body);
        }
        byte[] bodycrc = new byte[2];
        buffer.get(bodycrc);
        bean.setBodyfcs(bodycrc);
        byte[] crc = new byte[2];
        buffer.get(crc);
        bean.setFcs(crc);
        return dev;
    }

    @Override
    byte[] getCRC() throws DecodeException {
        return bean.getFcs();
    }

    @Override
    int getCrcBodySize() throws DecodeException {
        if (bean == null)
            throw new DecodeException("get crc body error,data is null", DecodeException.ERR.DECODE_BODYLEN_ERROR);
        int len = PacketConst.PACKET_F242_LEN + bean.getLength() - 3;
        return len;
    }

    @Override
    void decodeDevice(byte[] dev) throws DecodeException {
        if (dev == null)
            throw new DecodeException("data len is zero", DecodeException.ERR.DECODE_DEV_ERROR);
        if (dev.length != 8)
            throw new DecodeException("data len is not 8", DecodeException.ERR.DECODE_DEV_ERROR);
        ByteBuffer b = ByteBuffer.allocate(dev.length);
        b.put(dev);
        b.flip();
        bean.setCustomerId(b.getInt());
        bean.setDevType(b.get());
        bean.setDevSubType(b.get());
        bean.setDataVersion(b.getShort());
    }

    @Override
    ProtocolBean toBean() {
        return bean;
    }
}
