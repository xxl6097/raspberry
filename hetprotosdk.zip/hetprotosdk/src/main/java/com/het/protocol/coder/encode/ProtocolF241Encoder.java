package com.het.protocol.coder.encode;

import com.het.protocol.coder.bean.ProtocolBean;
import com.het.protocol.coder.exception.DecodeException;
import com.het.protocol.coder.exception.EncodeException;

import java.nio.ByteBuffer;

/**
 * v41版本协议格式
 * -------------------------------------------------------------------------------------------------------------------------
 * | 0xF2 | Protocol Version | Protocol Type | Command Type | Mac Addr | Device Type | Reserved | Length | Frame Body | FCS  |
 * |-------------------------------------------------------------------------------------------------------------------------|
 * | 1byte|       1byte      |     1byte     |      2byte   |   6byte  |     2byte   |   1byte  |  2byte |   Nbyte    | 2byte|
 * -------------------------------------------------------------------------------------------------------------------------
 */
public class ProtocolF241Encoder extends AbstractEncoder {
    final int PACKET_SIZE = 18;

    @Override
    void encode(ProtocolBean bean, ByteBuffer buffer) throws DecodeException {
        buffer.put(bean.getHead());
        buffer.put(bean.getProtoVersion());
        buffer.put(bean.getProtoType());
        buffer.putShort(bean.getCommand());
        buffer.put(encodeMacAddress(bean.getDevMacAddr()));
        buffer.put(encodeDevice(bean));
        byte[] reserved = bean.getReserved();
        if (reserved == null || reserved.length != 1) {
            reserved = new byte[1];
        }
        buffer.put(reserved);

        byte[] body = bean.getBody();
        short bodylen = (short) (body == null ? 0 : body.length);
        buffer.putShort(bodylen);


        if (body != null && bodylen > 0) {
            buffer.put(body);
        }
        buffer.put(encodeCRC(buffer.array(), getDataLen(bean) - 3));
    }

    @Override
    short getDataLen(ProtocolBean bean) throws DecodeException {
        byte[] body = bean.getBody();
        int dataLen = PACKET_SIZE + (body == null ? 0 : body.length);
        return (short) dataLen;
    }

    @Override
    byte[] encodeDevice(ProtocolBean bean) throws DecodeException {
        ByteBuffer b = ByteBuffer.allocate(2);
        b.put((byte) bean.getDevType());
        b.put((byte) bean.getDevSubType());
        b.flip();
        return b.array();
    }
}
